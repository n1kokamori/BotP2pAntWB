from .menus import (
    main_menu, analytics_menu, rates_menu, settings_menu,
    services_menu, cancel_kb, quick_amounts_kb, confirm_kb,
    edit_confirm_kb, period_kb,
)
