from aiogram.types import (
    ReplyKeyboardMarkup, KeyboardButton,
    InlineKeyboardMarkup, InlineKeyboardButton,
)
from aiogram.utils.keyboard import ReplyKeyboardBuilder


def main_menu():
    kb = ReplyKeyboardBuilder()
    kb.row(KeyboardButton(text="🟢 Купил"), KeyboardButton(text="🔴 Продал"))
    kb.row(KeyboardButton(text="📊 Аналитика"), KeyboardButton(text="💱 Курсы"))
    kb.row(KeyboardButton(text="⚙️ Настройки"))
    return kb.as_markup(resize_keyboard=True)


def analytics_menu():
    kb = ReplyKeyboardBuilder()
    kb.row(KeyboardButton(text="📊 Быстрый итог"), KeyboardButton(text="📈 Полная статистика"))
    kb.row(KeyboardButton(text="📜 История"), KeyboardButton(text="🏦 По сервисам"))
    kb.row(KeyboardButton(text="← Назад"))
    return kb.as_markup(resize_keyboard=True)


def rates_menu():
    kb = ReplyKeyboardBuilder()
    kb.row(KeyboardButton(text="💱 Курс ЦБ"), KeyboardButton(text="✍️ P2P-курс"))
    kb.row(KeyboardButton(text="← Назад"))
    return kb.as_markup(resize_keyboard=True)


def settings_menu():
    kb = ReplyKeyboardBuilder()
    kb.row(KeyboardButton(text="⚙️ Комиссия WB"), KeyboardButton(text="⚙️ Комиссия продажи"))
    kb.row(KeyboardButton(text="📤 Экспорт CSV"), KeyboardButton(text="💾 Бэкап"))
    kb.row(KeyboardButton(text="✏️ Изменить сделку"), KeyboardButton(text="↩️ Отменить последнюю"))
    kb.row(KeyboardButton(text="← Назад"))
    return kb.as_markup(resize_keyboard=True)


def services_menu():
    kb = ReplyKeyboardBuilder()
    kb.row(KeyboardButton(text="P2P"), KeyboardButton(text="Antarctic"))
    kb.row(KeyboardButton(text="Whitebird"))
    kb.row(KeyboardButton(text="← Назад"))
    return kb.as_markup(resize_keyboard=True)


def cancel_kb():
    kb = ReplyKeyboardBuilder()
    kb.row(KeyboardButton(text="❌ Отмена"))
    return kb.as_markup(resize_keyboard=True)


def quick_amounts_kb():
    kb = ReplyKeyboardBuilder()
    kb.row(KeyboardButton(text="1 000"), KeyboardButton(text="5 000"))
    kb.row(KeyboardButton(text="10 000"), KeyboardButton(text="50 000"))
    kb.row(KeyboardButton(text="❌ Отмена"))
    return kb.as_markup(resize_keyboard=True)


def confirm_kb():
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="✅ Сохранить", callback_data="confirm:yes"),
        InlineKeyboardButton(text="✏️ Исправить", callback_data="confirm:edit"),
        InlineKeyboardButton(text="❌ Отмена", callback_data="confirm:cancel"),
    ]])


def edit_confirm_kb():
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="✅ Сохранить", callback_data="edit_confirm:yes"),
        InlineKeyboardButton(text="✏️ Исправить", callback_data="edit_confirm:edit"),
        InlineKeyboardButton(text="❌ Отмена", callback_data="edit_confirm:cancel"),
    ]])


PERIOD_LABELS = {
    "today": "сегодня",
    "week": "7 дней",
    "month": "30 дней",
    "all": "всё время",
}


def period_kb(active="all"):
    buttons = []
    for p, label in PERIOD_LABELS.items():
        mark = "• " if p == active else ""
        buttons.append(InlineKeyboardButton(
            text=f"{mark}{label}", callback_data=f"period:{p}"
        ))
    return InlineKeyboardMarkup(inline_keyboard=[buttons[:2], buttons[2:]])
