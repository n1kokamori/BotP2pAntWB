import asyncio
import logging

from aiogram import Bot, Dispatcher

from config import TOKEN
from database import init_db
from handlers import main_menu, deals, analytics, settings, rates

logging.basicConfig(level=logging.INFO)


async def main():
    await init_db()
    bot = Bot(TOKEN)
    dp = Dispatcher()

    dp.include_router(main_menu.router)
    dp.include_router(deals.router)
    dp.include_router(analytics.router)
    dp.include_router(settings.router)
    dp.include_router(rates.router)

    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
