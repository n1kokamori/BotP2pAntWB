import os

TOKEN = os.getenv("BOT_TOKEN", "8559170394:AAEe09BOo6mbtMwi6RTH77xwi72WoXEJPOo")
DB = "/data/p2p.db" if os.path.isdir("/data") else "p2p.db"

DEFAULT_WB_COMMISSION = 0.032   # 3.2%
DEFAULT_SELL_COMMISSION = 0.0   # 0%
CBR_URL = "https://www.cbr-xml-daily.ru/daily_json.js"
