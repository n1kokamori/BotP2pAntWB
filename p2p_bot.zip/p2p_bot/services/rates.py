import aiohttp
from config import CBR_URL


async def fetch_cbr_usd_rate():
    async with aiohttp.ClientSession() as sess:
        async with sess.get(CBR_URL, timeout=10) as r:
            data = await r.json()
    usd = data["Valute"]["USD"]
    rate = usd["Value"] / usd.get("Nominal", 1)
    date = data.get("Date", "")[:10]
    return rate, date
