PERIOD_LABELS = {
    "today": "сегодня",
    "week": "7 дней",
    "month": "30 дней",
    "all": "всё время",
}


def calculate_buy(rub, rate, service, wb_comm):
    """Возвращает (usdt, commission_rub, real_rate)."""
    if service == "whitebird":
        commission_rub = rub * wb_comm
        usdt = (rub - commission_rub) / rate
    else:
        commission_rub = 0.0
        usdt = rub / rate
    real_rate = rub / usdt if usdt else 0
    return usdt, commission_rub, real_rate


def calculate_sell(rub, rate, sell_comm):
    """Возвращает (usdt, commission_rub, net_rub, real_rate)."""
    usdt = rub / rate
    commission_rub = rub * sell_comm
    net_rub = rub - commission_rub
    real_rate = net_rub / usdt if usdt else 0
    return usdt, commission_rub, net_rub, real_rate


def format_stats(s, period):
    text = f"📊 <b>Статистика ({PERIOD_LABELS[period]})</b>\n\n"
    text += "<b>Покупки:</b>\n"
    text += f"  Потрачено: {s['buy_rub']:.2f} ₽\n"
    text += f"  Получено: {s['buy_usdt']:.2f} USDT\n"
    if s["buy_comm"]:
        text += f"  Комиссия Whitebird: {s['buy_comm']:.2f} ₽\n"
    if s["buy_usdt"]:
        text += f"  Средний реальный курс: {s['avg_buy_rate']:.2f} ₽/USDT\n"

    text += "\n<b>Продажи:</b>\n"
    if s["sell_usdt"]:
        text += f"  Получено (грязными): {s['sell_rub']:.2f} ₽\n"
        if s["sell_comm"]:
            text += f"  Комиссия продажи: {s['sell_comm']:.2f} ₽\n"
            text += f"  Чистая выручка: {s['sell_net_rub']:.2f} ₽\n"
        text += f"  Отдано: {s['sell_usdt']:.2f} USDT\n"
        text += f"  Средний курс продажи: {s['avg_sell_rate']:.2f} ₽/USDT\n"
    else:
        text += "  Пока нет продаж\n"

    text += "\n<b>💰 Баланс:</b>\n"
    text += f"  Остаток USDT: {s['balance_usdt']:.2f}\n"
    if s["balance_usdt"]:
        text += f"  Себестоимость остатка: {s['balance_cost']:.2f} ₽\n"

        if s["cbr_rate"]:
            text += (
                f"\n  <b>По ЦБ ({s['cbr_rate']:.2f}):</b>\n"
                f"    Стоимость: {s['value_cbr']:.2f} ₽\n"
                f"    Профит: {'+' if s['profit_cbr'] >= 0 else ''}{s['profit_cbr']:.2f} ₽\n"
            )
        else:
            text += "\n  <i>Курс ЦБ не задан — «💱 Курсы → 💱 Курс ЦБ»</i>\n"

        if s["p2p_rate"]:
            text += (
                f"\n  <b>По P2P ({s['p2p_rate']:.2f}):</b>\n"
                f"    Стоимость: {s['value_p2p']:.2f} ₽\n"
                f"    Профит: {'+' if s['profit_p2p'] >= 0 else ''}{s['profit_p2p']:.2f} ₽\n"
            )
        else:
            text += "\n  <i>P2P-курс не задан — «💱 Курсы → ✍️ P2P-курс»</i>"
    else:
        text += "  <i>Нет остатка USDT</i>"

    text += "\n\n<b>📈 Реализованный профит:</b>\n"
    if s["sell_usdt"]:
        text += f"  {'+' if s['profit'] >= 0 else ''}{s['profit']:.2f} ₽\n"
        if s["buy_usdt"] and s["sell_usdt"]:
            text += f"  Спред: {s['spread']:+.2f} ₽/USDT"
    else:
        text += "  Нет (USDT ещё не продан)"
    return text


def format_quick_summary(s):
    lines = []
    if s["sell_usdt"]:
        lines.append(f"📈 Реализовано: {'+' if s['profit'] >= 0 else ''}{s['profit']:.2f} ₽")
    else:
        lines.append("📈 Реализовано: пока нет продаж")

    if s["balance_usdt"]:
        lines.append(f"💰 Остаток: {s['balance_usdt']:.2f} USDT")
        if s["cbr_rate"]:
            lines.append(
                f"  · ЦБ {s['cbr_rate']:.2f} → {s['value_cbr']:.0f} ₽ "
                f"({'+' if s['profit_cbr'] >= 0 else ''}{s['profit_cbr']:.0f} ₽)"
            )
        if s["p2p_rate"]:
            lines.append(
                f"  · P2P {s['p2p_rate']:.2f} → {s['value_p2p']:.0f} ₽ "
                f"({'+' if s['profit_p2p'] >= 0 else ''}{s['profit_p2p']:.0f} ₽)"
            )
        if not s["cbr_rate"] and not s["p2p_rate"]:
            lines.append("  · курсы не заданы")
    else:
        lines.append("💰 Остаток: 0 USDT")
    return "\n".join(lines)
