from . import main_menu, deals, analytics, settings, rates
