from aiogram import Router, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

from keyboards import main_menu, analytics_menu, rates_menu, settings_menu

router = Router()


@router.message(Command("start"))
async def start(m: Message, state: FSMContext):
    await state.clear()
    await m.answer("P2P-трекер. Выбери действие:", reply_markup=main_menu())


@router.message(Command("cancel"))
async def cancel_cmd(m: Message, state: FSMContext):
    await state.clear()
    await m.answer("❌ Отменено.", reply_markup=main_menu())


@router.message(F.text == "❌ Отмена")
async def cancel_btn(m: Message, state: FSMContext):
    await state.clear()
    await m.answer("❌ Отменено.", reply_markup=main_menu())


@router.message(F.text == "← Назад")
async def back(m: Message, state: FSMContext):
    await state.clear()
    await m.answer("Главное меню:", reply_markup=main_menu())


@router.message(F.text == "📊 Аналитика")
async def open_analytics(m: Message, state: FSMContext):
    await state.clear()
    await m.answer("📊 Аналитика:", reply_markup=analytics_menu())


@router.message(F.text == "💱 Курсы")
async def open_rates(m: Message, state: FSMContext):
    await state.clear()
    await m.answer("💱 Курсы:", reply_markup=rates_menu())


@router.message(F.text == "⚙️ Настройки")
async def open_settings(m: Message, state: FSMContext):
    await state.clear()
    await m.answer("⚙️ Настройки:", reply_markup=settings_menu())
