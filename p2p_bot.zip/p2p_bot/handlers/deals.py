from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery

from database import add_deal, get_stats, get_wb_commission, get_sell_commission
from keyboards import main_menu, services_menu, cancel_kb, quick_amounts_kb, confirm_kb
from services.calculations import calculate_buy, calculate_sell

router = Router()


class BuyStates(StatesGroup):
    service = State()
    rub = State()
    rate = State()
    confirm = State()


class SellStates(StatesGroup):
    rub = State()
    rate = State()
    confirm = State()


# ---------- ПОКУПКА ----------
@router.message(F.text == "🟢 Купил")
async def buy_start(m: Message, state: FSMContext):
    await m.answer("Выбери сервис:", reply_markup=services_menu())
    await state.set_state(BuyStates.service)


@router.message(BuyStates.service, F.text.in_({"P2P", "Antarctic", "Whitebird"}))
async def buy_service(m: Message, state: FSMContext):
    await state.update_data(service=m.text.lower())
    await m.answer("Сумма в рублях:", reply_markup=quick_amounts_kb())
    await state.set_state(BuyStates.rub)


@router.message(BuyStates.rub)
async def buy_rub(m: Message, state: FSMContext):
    text = m.text.replace(" ", "").replace(",", ".")
    try:
        rub = float(text)
        assert rub > 0
    except (ValueError, AssertionError):
        return await m.answer("⚠️ Введи положительное число:", reply_markup=quick_amounts_kb())
    await state.update_data(rub=rub)
    await m.answer("Курс покупки (₽ за 1 USDT):", reply_markup=cancel_kb())
    await state.set_state(BuyStates.rate)


@router.message(BuyStates.rate)
async def buy_rate(m: Message, state: FSMContext):
    try:
        rate = float(m.text.replace(",", "."))
        assert rate > 0
    except (ValueError, AssertionError):
        return await m.answer("⚠️ Введи положительное число:", reply_markup=cancel_kb())

    if not (30 <= rate <= 300):
        return await m.answer(
            f"⚠️ Курс {rate:.2f} выглядит подозрительно (обычно 50–200). Введи ещё раз:",
            reply_markup=cancel_kb()
        )

    data = await state.get_data()
    rub, service = data["rub"], data["service"]

    wb_comm = await get_wb_commission(m.from_user.id)
    usdt, commission_rub, real_rate = calculate_buy(rub, rate, service, wb_comm)
    await state.update_data(rate=rate, usdt=usdt, commission_rub=commission_rub)

    svc_name = "P2P" if service == "p2p" else service.capitalize()
    text = (
        f"🧮 <b>Предварительный расчёт</b>\n"
        f"Сервис: {svc_name}\n"
        f"Сумма: {rub:.2f} ₽\n"
        f"Курс: {rate:.2f} ₽\n"
    )
    if commission_rub:
        text += (
            f"Комиссия: {commission_rub:.2f} ₽ ({wb_comm*100:.1f}%)\n"
            f"На покупку: {rub - commission_rub:.2f} ₽\n"
        )
    text += (
        f"Получишь: <b>{usdt:.2f} USDT</b>\n"
        f"Реальный курс: {real_rate:.2f} ₽/USDT\n\n"
        f"Сохранить?"
    )
    await m.answer(text, parse_mode="HTML", reply_markup=confirm_kb())
    await state.set_state(BuyStates.confirm)


# ---------- ПРОДАЖА ----------
@router.message(F.text == "🔴 Продал")
async def sell_start(m: Message, state: FSMContext):
    await m.answer("Сумма в рублях:", reply_markup=quick_amounts_kb())
    await state.set_state(SellStates.rub)


@router.message(SellStates.rub)
async def sell_rub(m: Message, state: FSMContext):
    text = m.text.replace(" ", "").replace(",", ".")
    try:
        rub = float(text)
        assert rub > 0
    except (ValueError, AssertionError):
        return await m.answer("⚠️ Введи положительное число:", reply_markup=quick_amounts_kb())
    await state.update_data(rub=rub)
    await m.answer("Курс продажи (₽ за 1 USDT):", reply_markup=cancel_kb())
    await state.set_state(SellStates.rate)


@router.message(SellStates.rate)
async def sell_rate(m: Message, state: FSMContext):
    try:
        rate = float(m.text.replace(",", "."))
        assert rate > 0
    except (ValueError, AssertionError):
        return await m.answer("⚠️ Введи положительное число:", reply_markup=cancel_kb())

    if not (30 <= rate <= 300):
        return await m.answer(
            f"⚠️ Курс {rate:.2f} выглядит подозрительно (обычно 50–200). Введи ещё раз:",
            reply_markup=cancel_kb()
        )

    data = await state.get_data()
    rub = data["rub"]

    sell_comm_pct = await get_sell_commission(m.from_user.id)
    usdt, commission_rub, net_rub, real_rate = calculate_sell(rub, rate, sell_comm_pct)
    await state.update_data(rate=rate, usdt=usdt, commission_rub=commission_rub)

    s = await get_stats(m.from_user.id, "all")
    balance_after = s["balance_usdt"] - usdt

    text = (
        f"🧮 <b>Предварительный расчёт</b>\n"
        f"Сумма: {rub:.2f} ₽\n"
        f"Курс: {rate:.2f} ₽\n"
        f"Отдашь: <b>{usdt:.2f} USDT</b>\n"
    )
    if commission_rub:
        text += (
            f"Комиссия: {commission_rub:.2f} ₽ ({sell_comm_pct*100:.2f}%)\n"
            f"На руки: {net_rub:.2f} ₽\n"
        )
    text += (
        f"Реальный курс: {real_rate:.2f} ₽/USDT\n"
        f"Остаток после: {balance_after:.2f} USDT"
    )
    if balance_after < 0:
        text += "\n⚠️ <b>Внимание: остаток уйдёт в минус!</b>"
    text += "\n\nСохранить?"

    await m.answer(text, parse_mode="HTML", reply_markup=confirm_kb())
    await state.set_state(SellStates.confirm)


# ---------- ПОДТВЕРЖДЕНИЕ (покупка/продажа) ----------
@router.callback_query(F.data.startswith("confirm:"))
async def confirm_router(cb: CallbackQuery, state: FSMContext):
    action = cb.data.split(":", 1)[1]
    current_state = await state.get_state()
    data = await state.get_data()

    if action == "cancel":
        await state.clear()
        await cb.message.edit_text("❌ Отменено.")
        await cb.message.answer("Главное меню:", reply_markup=main_menu())
        await cb.answer()
        return

    if action == "edit":
        if current_state == BuyStates.confirm.state:
            await state.set_state(BuyStates.rub)
        elif current_state == SellStates.confirm.state:
            await state.set_state(SellStates.rub)
        else:
            await cb.answer("⚠️ Состояние устарело")
            return
        await cb.message.edit_text("✏️ Введи сумму заново:")
        await cb.message.answer("Сумма в рублях:", reply_markup=quick_amounts_kb())
        await cb.answer()
        return

    if current_state == BuyStates.confirm.state:
        await add_deal(cb.from_user.id, "buy", data["service"],
                       data["rub"], data["rate"], data["usdt"], data["commission_rub"])
        await cb.message.edit_text("✅ Покупка сохранена.")
    elif current_state == SellStates.confirm.state:
        await add_deal(cb.from_user.id, "sell", "sell",
                       data["rub"], data["rate"], data["usdt"], data["commission_rub"])
        await cb.message.edit_text("✅ Продажа сохранена.")
    else:
        await cb.answer("⚠️ Состояние устарело")
        return

    await cb.message.answer("Главное меню:", reply_markup=main_menu())
    await state.clear()
    await cb.answer()
