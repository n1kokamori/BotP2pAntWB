from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton

from database import get_stats, save_current_rate, save_p2p_rate, get_rates
from keyboards import rates_menu, cancel_kb
from services.rates import fetch_cbr_usd_rate

router = Router()


class RateStates(StatesGroup):
    manual = State()
    p2p = State()


@router.message(F.text == "💱 Курс ЦБ")
async def usdt_rate(m: Message):
    try:
        rub_rate, cbr_date = await fetch_cbr_usd_rate()
        await save_current_rate(m.from_user.id, rub_rate)

        s = await get_stats(m.from_user.id, "all")
        text = (
            f"💱 <b>Курс ЦБ сохранён</b>\n\n"
            f"Официальный USD: <b>{rub_rate:.4f} ₽</b>\n"
            f"Дата ЦБ: {cbr_date}\n"
            f"<i>USDT ≈ 1 USD</i>\n"
        )
        if s["balance_usdt"]:
            text += (
                f"\n<b>Остаток:</b> {s['balance_usdt']:.2f} USDT\n"
                f"  По ЦБ: {s['value_cbr']:.2f} ₽ "
                f"({'%+.2f' % s['profit_cbr']} ₽)\n"
            )
            if s["p2p_rate"]:
                text += (
                    f"  По P2P ({s['p2p_rate']:.2f}): {s['value_p2p']:.2f} ₽ "
                    f"({'%+.2f' % s['profit_p2p']} ₽)"
                )
        await m.answer(text, parse_mode="HTML", reply_markup=rates_menu())
    except Exception as e:
        await m.answer(
            f"⚠️ Не удалось получить курс ЦБ: {e}\nМожешь задать вручную:",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="✍️ Задать ЦБ вручную", callback_data="rate_manual")
            ]])
        )


@router.callback_query(F.data == "rate_manual")
async def rate_manual_start(cb: CallbackQuery, state: FSMContext):
    await cb.message.answer("Введи курс ЦБ (USD→₽) вручную, например 83.5:",
                            reply_markup=cancel_kb())
    await state.set_state(RateStates.manual)
    await cb.answer()


@router.message(RateStates.manual)
async def rate_manual_save(m: Message, state: FSMContext):
    try:
        rate = float(m.text.replace(",", "."))
        assert rate > 0
    except (ValueError, AssertionError):
        return await m.answer("⚠️ Введи положительное число", reply_markup=cancel_kb())

    await save_current_rate(m.from_user.id, rate)
    s = await get_stats(m.from_user.id, "all")
    text = f"✅ Курс ЦБ сохранён: <b>{rate:.2f} ₽/USDT</b>\n"
    if s["balance_usdt"]:
        text += (
            f"\nОстаток: {s['balance_usdt']:.2f} USDT\n"
            f"  По ЦБ: {s['value_cbr']:.2f} ₽ "
            f"({'%+.2f' % s['profit_cbr']} ₽)"
        )
    await m.answer(text, parse_mode="HTML", reply_markup=rates_menu())
    await state.clear()


@router.message(F.text == "✍️ P2P-курс")
async def p2p_rate_start(m: Message, state: FSMContext):
    current = await get_rates(m.from_user.id)
    hint = f"\nТекущий P2P-курс: {current[1]:.2f} ₽" if current[1] else ""
    await m.answer(
        f"Введи P2P-курс USDT в рублях (по которому реально продаёшь){hint}:",
        reply_markup=cancel_kb()
    )
    await state.set_state(RateStates.p2p)


@router.message(RateStates.p2p)
async def p2p_rate_save(m: Message, state: FSMContext):
    try:
        rate = float(m.text.replace(",", "."))
        assert rate > 0
    except (ValueError, AssertionError):
        return await m.answer("⚠️ Введи положительное число, например 97.5",
                              reply_markup=cancel_kb())

    await save_p2p_rate(m.from_user.id, rate)
    s = await get_stats(m.from_user.id, "all")

    text = f"✅ P2P-курс сохранён: <b>{rate:.2f} ₽/USDT</b>\n"
    if s["balance_usdt"]:
        text += (
            f"\n<b>Остаток:</b> {s['balance_usdt']:.2f} USDT\n"
            f"  По P2P: {s['value_p2p']:.2f} ₽ "
            f"({'%+.2f' % s['profit_p2p']} ₽)\n"
        )
        if s["cbr_rate"]:
            text += (
                f"  По ЦБ ({s['cbr_rate']:.2f}): {s['value_cbr']:.2f} ₽ "
                f"({'%+.2f' % s['profit_cbr']} ₽)"
            )
    await m.answer(text, parse_mode="HTML", reply_markup=rates_menu())
    await state.clear()
