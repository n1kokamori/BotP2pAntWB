from aiogram import Router, F
from aiogram.types import Message, CallbackQuery

from database import get_stats, get_stats_by_service, get_history
from keyboards import analytics_menu, period_kb
from services.calculations import format_stats, format_quick_summary

router = Router()


@router.message(F.text == "📊 Быстрый итог")
async def quick_summary(m: Message):
    s = await get_stats(m.from_user.id, "all")
    if not (s["buy_rub"] or s["sell_rub"]):
        return await m.answer("⚠️ Пока нет сделок.", reply_markup=analytics_menu())
    await m.answer(format_quick_summary(s), reply_markup=analytics_menu())


@router.message(F.text == "📈 Полная статистика")
async def stats(m: Message):
    s = await get_stats(m.from_user.id, "all")
    if not (s["buy_rub"] or s["sell_rub"]):
        return await m.answer("⚠️ Пока нет сделок.", reply_markup=analytics_menu())
    await m.answer(format_stats(s, "all"), parse_mode="HTML",
                   reply_markup=period_kb("all"))


@router.callback_query(F.data.startswith("period:"))
async def stats_period(cb: CallbackQuery):
    period = cb.data.split(":", 1)[1]
    s = await get_stats(cb.from_user.id, period)
    if not (s["buy_rub"] or s["sell_rub"]):
        await cb.answer("За этот период сделок нет")
        return
    await cb.message.edit_text(
        format_stats(s, period), parse_mode="HTML",
        reply_markup=period_kb(period)
    )
    await cb.answer()


@router.message(F.text == "📜 История")
async def history(m: Message):
    rows = await get_history(m.from_user.id, limit=15)
    if not rows:
        return await m.answer("📜 История пуста.", reply_markup=analytics_menu())

    lines = ["📜 <b>Последние сделки</b>\n"]
    for t, service, rub, rate, usdt, comm, created in rows:
        icon = "🟢" if t == "buy" else "🔴"
        svc = ("P2P" if service == "p2p" else service.capitalize()) if t == "buy" else "Продажа"
        line = (
            f"{icon} <b>{svc}</b> · {created[:16]}\n"
            f"   {rub:.2f} ₽ @ {rate:.2f} → {usdt:.2f} USDT"
        )
        if comm:
            line += f" (ком. {comm:.2f} ₽)"
        lines.append(line)
    await m.answer("\n".join(lines), parse_mode="HTML", reply_markup=analytics_menu())


@router.message(F.text == "🏦 По сервисам")
async def stats_by_service(m: Message):
    rows = await get_stats_by_service(m.from_user.id)
    if not rows:
        return await m.answer("⚠️ Покупок пока нет.", reply_markup=analytics_menu())

    lines = ["🏦 <b>Статистика по сервисам</b>\n"]
    total_rub = total_usdt = total_comm = 0

    for service, rub, usdt, comm, cnt in rows:
        rub, usdt, comm = rub or 0, usdt or 0, comm or 0
        real_rate = rub / usdt if usdt else 0
        svc_name = "P2P" if service == "p2p" else service.capitalize()
        lines.append(
            f"<b>{svc_name}</b> ({cnt} сделок)\n"
            f"  Потрачено: {rub:.2f} ₽\n"
            f"  Получено: {usdt:.2f} USDT\n"
        )
        if comm:
            lines.append(f"  Комиссия: {comm:.2f} ₽\n")
        lines.append(f"  Реальный курс: {real_rate:.2f} ₽/USDT\n")
        total_rub += rub
        total_usdt += usdt
        total_comm += comm

    lines.append("\n<b>Всего по покупкам:</b>\n")
    lines.append(f"  Потрачено: {total_rub:.2f} ₽\n")
    lines.append(f"  Получено: {total_usdt:.2f} USDT\n")
    if total_comm:
        lines.append(f"  Комиссия: {total_comm:.2f} ₽\n")
    if total_usdt:
        lines.append(f"  Средний реальный курс: {total_rub / total_usdt:.2f} ₽/USDT")

    await m.answer("".join(lines), parse_mode="HTML", reply_markup=analytics_menu())
