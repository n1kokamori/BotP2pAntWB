import csv
import io

from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery, BufferedInputFile

from config import DB
from database import (
    get_all_deals, get_history_with_id, update_deal, delete_last,
    get_wb_commission, save_wb_commission,
    get_sell_commission, save_sell_commission,
)
from keyboards import (
    main_menu, settings_menu, cancel_kb, quick_amounts_kb, edit_confirm_kb,
)
from services.calculations import calculate_buy, calculate_sell

router = Router()


class EditStates(StatesGroup):
    pick = State()
    rub = State()
    rate = State()
    confirm = State()


class CommissionStates(StatesGroup):
    value = State()
    sell_value = State()


# ---------- ЭКСПОРТ ----------
@router.message(F.text == "📤 Экспорт CSV")
async def export_csv(m: Message):
    rows = await get_all_deals(m.from_user.id)
    if not rows:
        return await m.answer("⚠️ Нечего экспортировать.", reply_markup=settings_menu())

    buf = io.StringIO()
    writer = csv.writer(buf, delimiter=";")
    writer.writerow([
        "id", "created_at", "type", "service",
        "rub", "rate", "usdt", "commission_rub", "real_rate"
    ])
    for did, created, t, service, rub, rate, usdt, comm in rows:
        real_rate = rub / usdt if usdt else 0
        writer.writerow([
            did, created, t, service,
            f"{rub:.2f}", f"{rate:.4f}", f"{usdt:.6f}",
            f"{comm:.2f}", f"{real_rate:.4f}"
        ])

    file = BufferedInputFile(buf.getvalue().encode("utf-8-sig"), filename="p2p_deals.csv")
    await m.answer_document(file, caption="📤 Экспорт всех сделок")


# ---------- БЭКАП ----------
@router.message(F.text == "💾 Бэкап")
async def backup_db(m: Message):
    try:
        with open(DB, "rb") as f:
            data = f.read()
        file = BufferedInputFile(data, filename="p2p_backup.db")
        await m.answer_document(file, caption="💾 Бэкап базы данных")
    except Exception as e:
        await m.answer(f"⚠️ Не удалось сделать бэкап: {e}",
                       reply_markup=settings_menu())


# ---------- РЕДАКТИРОВАНИЕ СДЕЛКИ ----------
@router.message(F.text == "✏️ Изменить сделку")
async def edit_start(m: Message, state: FSMContext):
    rows = await get_history_with_id(m.from_user.id, limit=10)
    if not rows:
        return await m.answer("⚠️ Сделок нет.", reply_markup=settings_menu())

    lines = ["✏️ <b>Последние 10 сделок</b>\n"]
    for idx, (did, t, service, rub, rate, usdt, comm, created) in enumerate(rows, 1):
        icon = "🟢" if t == "buy" else "🔴"
        svc = ("P2P" if service == "p2p" else service.capitalize()) if t == "buy" else "Продажа"
        lines.append(
            f"{idx}. {icon} {svc} · {created[:10]}\n"
            f"   {rub:.0f} ₽ @ {rate:.2f} → {usdt:.2f} USDT"
        )
    lines.append("\nВведи номер сделки (1–10):")
    await m.answer("\n".join(lines), parse_mode="HTML", reply_markup=cancel_kb())
    await state.set_state(EditStates.pick)


@router.message(EditStates.pick)
async def edit_pick(m: Message, state: FSMContext):
    try:
        n = int(m.text.strip())
        assert 1 <= n <= 10
    except (ValueError, AssertionError):
        return await m.answer("⚠️ Введи число от 1 до 10", reply_markup=cancel_kb())

    rows = await get_history_with_id(m.from_user.id, limit=10)
    if n > len(rows):
        return await m.answer("⚠️ Сделки с таким номером нет", reply_markup=cancel_kb())

    did, t, service, rub, rate, usdt, comm, created = rows[n - 1]
    await state.update_data(deal_id=did, type=t, service=service)
    svc = ("P2P" if service == "p2p" else service.capitalize()) if t == "buy" else "Продажа"
    await m.answer(
        f"✏️ Редактируем сделку #{did} ({svc})\n"
        f"Было: {rub:.2f} ₽ @ {rate:.2f} → {usdt:.2f} USDT\n\n"
        f"Введи новую сумму в рублях:",
        reply_markup=quick_amounts_kb()
    )
    await state.set_state(EditStates.rub)


@router.message(EditStates.rub)
async def edit_rub(m: Message, state: FSMContext):
    text = m.text.replace(" ", "").replace(",", ".")
    try:
        rub = float(text)
        assert rub > 0
    except (ValueError, AssertionError):
        return await m.answer("⚠️ Введи положительное число:", reply_markup=quick_amounts_kb())
    await state.update_data(rub=rub)
    await m.answer("Введи новый курс (₽ за 1 USDT):", reply_markup=cancel_kb())
    await state.set_state(EditStates.rate)


@router.message(EditStates.rate)
async def edit_rate(m: Message, state: FSMContext):
    try:
        rate = float(m.text.replace(",", "."))
        assert rate > 0
    except (ValueError, AssertionError):
        return await m.answer("⚠️ Введи положительное число:", reply_markup=cancel_kb())

    if not (30 <= rate <= 300):
        return await m.answer(
            f"⚠️ Курс {rate:.2f} выглядит подозрительно (обычно 50–200). Введи ещё раз:",
            reply_markup=cancel_kb()
        )

    data = await state.get_data()
    rub, did, t, service = data["rub"], data["deal_id"], data["type"], data["service"]

    if t == "buy":
        wb_comm = await get_wb_commission(m.from_user.id)
        usdt, comm, _ = calculate_buy(rub, rate, service, wb_comm)
    else:
        sell_comm = await get_sell_commission(m.from_user.id)
        usdt, comm, _, _ = calculate_sell(rub, rate, sell_comm)

    await state.update_data(rate=rate, usdt=usdt, commission_rub=comm)

    svc = ("P2P" if service == "p2p" else service.capitalize()) if t == "buy" else "Продажа"
    text = (
        f"🧮 <b>Предварительный расчёт</b>\n"
        f"Сделка #{did} · {svc}\n"
        f"Сумма: {rub:.2f} ₽\n"
        f"Курс: {rate:.2f} ₽\n"
    )
    if comm:
        text += f"Комиссия: {comm:.2f} ₽\n"
    text += f"USDT: {usdt:.2f}\n\nСохранить?"

    await m.answer(text, parse_mode="HTML", reply_markup=edit_confirm_kb())
    await state.set_state(EditStates.confirm)


@router.callback_query(F.data.startswith("edit_confirm:"))
async def edit_confirm_router(cb: CallbackQuery, state: FSMContext):
    action = cb.data.split(":", 1)[1]
    data = await state.get_data()

    if action == "cancel":
        await state.clear()
        await cb.message.edit_text("❌ Отменено.")
        await cb.message.answer("Главное меню:", reply_markup=settings_menu())
        await cb.answer()
        return

    if action == "edit":
        await state.set_state(EditStates.rub)
        await cb.message.edit_text("✏️ Введи сумму заново:")
        await cb.message.answer("Сумма в рублях:", reply_markup=quick_amounts_kb())
        await cb.answer()
        return

    await update_deal(data["deal_id"], data["rub"], data["rate"],
                      data["usdt"], data["commission_rub"])
    await cb.message.edit_text(f"✅ Сделка #{data['deal_id']} обновлена.")
    await cb.message.answer("Главное меню:", reply_markup=main_menu())
    await state.clear()
    await cb.answer()


# ---------- ОТМЕНИТЬ ПОСЛЕДНЮЮ ----------
@router.message(F.text == "↩️ Отменить последнюю")
async def cancel_last(m: Message):
    deleted = await delete_last(m.from_user.id)
    if deleted is None:
        await m.answer("⚠️ Нечего отменять.", reply_markup=settings_menu())
    else:
        await m.answer(f"🗑 Удалена сделка #{deleted}", reply_markup=settings_menu())


# ---------- КОМИССИЯ WB ----------
@router.message(F.text == "⚙️ Комиссия WB")
async def wb_commission_menu(m: Message, state: FSMContext):
    current = await get_wb_commission(m.from_user.id)
    await m.answer(
        f"⚙️ Текущая комиссия Whitebird: <b>{current*100:.2f}%</b>\n\n"
        f"Введи новый процент (например 3.2):",
        parse_mode="HTML", reply_markup=cancel_kb()
    )
    await state.set_state(CommissionStates.value)


@router.message(CommissionStates.value)
async def wb_commission_save(m: Message, state: FSMContext):
    try:
        percent = float(m.text.replace(",", ".").replace("%", "").strip())
        assert 0 <= percent < 100
    except (ValueError, AssertionError):
        return await m.answer("⚠️ Введи процент от 0 до 100:", reply_markup=cancel_kb())

    await save_wb_commission(m.from_user.id, percent / 100)
    await m.answer(
        f"✅ Комиссия Whitebird сохранена: <b>{percent:.2f}%</b>",
        parse_mode="HTML", reply_markup=settings_menu()
    )
    await state.clear()


# ---------- КОМИССИЯ ПРОДАЖИ ----------
@router.message(F.text == "⚙️ Комиссия продажи")
async def sell_commission_menu(m: Message, state: FSMContext):
    current = await get_sell_commission(m.from_user.id)
    await m.answer(
        f"⚙️ Текущая комиссия при продаже: <b>{current*100:.2f}%</b>\n\n"
        f"Введи новый процент (например 1.5 или 0):",
        parse_mode="HTML", reply_markup=cancel_kb()
    )
    await state.set_state(CommissionStates.sell_value)


@router.message(CommissionStates.sell_value)
async def sell_commission_save(m: Message, state: FSMContext):
    try:
        percent = float(m.text.replace(",", ".").replace("%", "").strip())
        assert 0 <= percent < 100
    except (ValueError, AssertionError):
        return await m.answer("⚠️ Введи процент от 0 до 100:", reply_markup=cancel_kb())

    await save_sell_commission(m.from_user.id, percent / 100)
    await m.answer(
        f"✅ Комиссия продажи сохранена: <b>{percent:.2f}%</b>",
        parse_mode="HTML", reply_markup=settings_menu()
    )
    await state.clear()
