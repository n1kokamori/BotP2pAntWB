import aiosqlite
from datetime import datetime, timedelta

from config import DB, DEFAULT_WB_COMMISSION, DEFAULT_SELL_COMMISSION


# ---------- сделки ----------
async def add_deal(user_id, type_, service, rub, rate, usdt, commission_rub=0):
    async with aiosqlite.connect(DB) as db:
        await db.execute(
            "INSERT INTO deals (user_id, type, service, rub, rate, usdt, commission_rub) "
            "VALUES (?,?,?,?,?,?,?)",
            (user_id, type_, service, rub, rate, usdt, commission_rub)
        )
        await db.commit()


async def update_deal(deal_id, rub, rate, usdt, commission_rub):
    async with aiosqlite.connect(DB) as db:
        await db.execute(
            "UPDATE deals SET rub=?, rate=?, usdt=?, commission_rub=? WHERE id=?",
            (rub, rate, usdt, commission_rub, deal_id)
        )
        await db.commit()


async def delete_last(user_id):
    async with aiosqlite.connect(DB) as db:
        async with db.execute(
            "SELECT id FROM deals WHERE user_id=? ORDER BY id DESC LIMIT 1", (user_id,)
        ) as cur:
            row = await cur.fetchone()
        if not row:
            return None
        await db.execute("DELETE FROM deals WHERE id=?", (row[0],))
        await db.commit()
        return row[0]


def period_filter(period: str):
    if period == "all":
        return "", []
    now = datetime.utcnow()
    if period == "today":
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    elif period == "week":
        start = now - timedelta(days=7)
    elif period == "month":
        start = now - timedelta(days=30)
    else:
        return "", []
    return " AND created_at >= ?", [start.strftime("%Y-%m-%d %H:%M:%S")]


async def get_stats(user_id, period="all"):
    cond, params = period_filter(period)
    async with aiosqlite.connect(DB) as db:
        async with db.execute(
            f"SELECT type, SUM(rub), SUM(usdt), SUM(commission_rub) "
            f"FROM deals WHERE user_id=?{cond} GROUP BY type",
            (user_id, *params)
        ) as cur:
            rows = await cur.fetchall()

    s = {"buy_rub": 0, "buy_usdt": 0, "buy_comm": 0,
         "sell_rub": 0, "sell_usdt": 0, "sell_comm": 0}
    for t, rub, usdt, comm in rows:
        if t == "buy":
            s["buy_rub"] = rub or 0
            s["buy_usdt"] = usdt or 0
            s["buy_comm"] = comm or 0
        else:
            s["sell_rub"] = rub or 0
            s["sell_usdt"] = usdt or 0
            s["sell_comm"] = comm or 0

    s["sell_net_rub"] = s["sell_rub"] - s["sell_comm"]
    s["avg_buy_rate"] = s["buy_rub"] / s["buy_usdt"] if s["buy_usdt"] else 0
    s["avg_sell_rate"] = s["sell_net_rub"] / s["sell_usdt"] if s["sell_usdt"] else 0

    cost_of_sold = s["sell_usdt"] * s["avg_buy_rate"]
    s["profit"] = (s["sell_net_rub"] - cost_of_sold) if s["sell_usdt"] else 0

    s["balance_usdt"] = s["buy_usdt"] - s["sell_usdt"]
    s["balance_cost"] = s["balance_usdt"] * s["avg_buy_rate"]
    s["spread"] = (s["avg_sell_rate"] - s["avg_buy_rate"]) if (s["buy_usdt"] and s["sell_usdt"]) else 0

    cbr_rate, p2p_rate, updated_at = await get_rates(user_id)
    s["cbr_rate"] = cbr_rate or 0
    s["p2p_rate"] = p2p_rate or 0
    s["rates_updated"] = updated_at

    if s["balance_usdt"]:
        s["value_cbr"] = s["balance_usdt"] * s["cbr_rate"] if s["cbr_rate"] else 0
        s["profit_cbr"] = s["value_cbr"] - s["balance_cost"] if s["cbr_rate"] else 0
        s["value_p2p"] = s["balance_usdt"] * s["p2p_rate"] if s["p2p_rate"] else 0
        s["profit_p2p"] = s["value_p2p"] - s["balance_cost"] if s["p2p_rate"] else 0
    else:
        s["value_cbr"] = s["profit_cbr"] = 0
        s["value_p2p"] = s["profit_p2p"] = 0

    return s


async def get_stats_by_service(user_id):
    async with aiosqlite.connect(DB) as db:
        async with db.execute(
            "SELECT service, SUM(rub), SUM(usdt), SUM(commission_rub), COUNT(*) "
            "FROM deals WHERE user_id=? AND type='buy' GROUP BY service",
            (user_id,)
        ) as cur:
            return await cur.fetchall()


async def get_all_deals(user_id):
    async with aiosqlite.connect(DB) as db:
        async with db.execute(
            "SELECT id, created_at, type, service, rub, rate, usdt, commission_rub "
            "FROM deals WHERE user_id=? ORDER BY id",
            (user_id,)
        ) as cur:
            return await cur.fetchall()


async def get_history(user_id, limit=10):
    async with aiosqlite.connect(DB) as db:
        async with db.execute(
            "SELECT type, service, rub, rate, usdt, commission_rub, created_at "
            "FROM deals WHERE user_id=? ORDER BY id DESC LIMIT ?",
            (user_id, limit)
        ) as cur:
            return await cur.fetchall()


async def get_history_with_id(user_id, limit=10):
    async with aiosqlite.connect(DB) as db:
        async with db.execute(
            "SELECT id, type, service, rub, rate, usdt, commission_rub, created_at "
            "FROM deals WHERE user_id=? ORDER BY id DESC LIMIT ?",
            (user_id, limit)
        ) as cur:
            return await cur.fetchall()


# ---------- настройки ----------
async def save_current_rate(user_id, rate):
    async with aiosqlite.connect(DB) as db:
        await db.execute(
            "INSERT INTO settings (user_id, current_rate, updated_at) "
            "VALUES (?, ?, CURRENT_TIMESTAMP) "
            "ON CONFLICT(user_id) DO UPDATE SET "
            "current_rate=excluded.current_rate, updated_at=CURRENT_TIMESTAMP",
            (user_id, rate)
        )
        await db.commit()


async def save_p2p_rate(user_id, rate):
    async with aiosqlite.connect(DB) as db:
        await db.execute(
            "INSERT INTO settings (user_id, p2p_rate, updated_at) "
            "VALUES (?, ?, CURRENT_TIMESTAMP) "
            "ON CONFLICT(user_id) DO UPDATE SET "
            "p2p_rate=excluded.p2p_rate, updated_at=CURRENT_TIMESTAMP",
            (user_id, rate)
        )
        await db.commit()


async def get_rates(user_id):
    async with aiosqlite.connect(DB) as db:
        async with db.execute(
            "SELECT current_rate, p2p_rate, updated_at FROM settings WHERE user_id=?",
            (user_id,)
        ) as cur:
            row = await cur.fetchone()
            return row if row else (None, None, None)


async def get_wb_commission(user_id):
    async with aiosqlite.connect(DB) as db:
        async with db.execute(
            "SELECT whitebird_commission FROM settings WHERE user_id=?",
            (user_id,)
        ) as cur:
            row = await cur.fetchone()
    return row[0] if (row and row[0] is not None) else DEFAULT_WB_COMMISSION


async def save_wb_commission(user_id, value):
    async with aiosqlite.connect(DB) as db:
        await db.execute(
            "INSERT INTO settings (user_id, whitebird_commission, updated_at) "
            "VALUES (?, ?, CURRENT_TIMESTAMP) "
            "ON CONFLICT(user_id) DO UPDATE SET "
            "whitebird_commission=excluded.whitebird_commission, "
            "updated_at=CURRENT_TIMESTAMP",
            (user_id, value)
        )
        await db.commit()


async def get_sell_commission(user_id):
    async with aiosqlite.connect(DB) as db:
        async with db.execute(
            "SELECT sell_commission FROM settings WHERE user_id=?",
            (user_id,)
        ) as cur:
            row = await cur.fetchone()
    return row[0] if (row and row[0] is not None) else DEFAULT_SELL_COMMISSION


async def save_sell_commission(user_id, value):
    async with aiosqlite.connect(DB) as db:
        await db.execute(
            "INSERT INTO settings (user_id, sell_commission, updated_at) "
            "VALUES (?, ?, CURRENT_TIMESTAMP) "
            "ON CONFLICT(user_id) DO UPDATE SET "
            "sell_commission=excluded.sell_commission, "
            "updated_at=CURRENT_TIMESTAMP",
            (user_id, value)
        )
        await db.commit()
