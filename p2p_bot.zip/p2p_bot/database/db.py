import aiosqlite
from config import DB


async def init_db():
    async with aiosqlite.connect(DB) as db:
        await db.execute("""
        CREATE TABLE IF NOT EXISTS deals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            type TEXT,
            service TEXT,
            rub REAL,
            rate REAL,
            usdt REAL,
            commission_rub REAL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            user_id INTEGER PRIMARY KEY,
            current_rate REAL,
            p2p_rate REAL,
            whitebird_commission REAL,
            sell_commission REAL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
        for col, typ in [
            ("p2p_rate", "REAL"),
            ("whitebird_commission", "REAL"),
            ("sell_commission", "REAL"),
        ]:
            try:
                await db.execute(f"ALTER TABLE settings ADD COLUMN {col} {typ}")
            except Exception:
                pass
        await db.commit()
