from .db import init_db
from .queries import (
    add_deal, update_deal, delete_last,
    get_stats, get_stats_by_service, get_all_deals,
    get_history, get_history_with_id,
    save_current_rate, save_p2p_rate, get_rates,
    get_wb_commission, save_wb_commission,
    get_sell_commission, save_sell_commission,
)
